<?php
	
	if(isset($_FILES['upload_file'])) {			
		$mail_to = 'jayakumar@omsinfotech.com';
		$subject = 'Enquiry Form';
		$message = "<p>Name : " . $_POST['name'] . "</p>";
		$message .= "<p>E mail : " . $_POST['email'] . "</p>";
		$message .= "<p>Mobile : " . $_POST['mobileno'] . "</p>";
		$message .= "<p>Comment : " . $_POST['comment'] . "</p>";
	
		if(mail($mail_to,$subject,$message,$headers)) {
			echo "<script>
				 alert('You Have Submitted Successfully We Will Contact Soon !');
			window.location = 'index.html'</script>";
		} else {
			echo "<script>
				 alert('You Have Submitted Successfully We Will Contact Soon !');
			window.location = 'index.html'</script>";
		}
	}
 

	else {
		$mail_to = 'jayakumar@omsinfotech.com';
		$subject = 'Enquiry Form';
	    $message = "<p>Name : " . $_POST['name'] . "</p>";
		$message = "<p>Name : " . $_POST['name'] . "</p>";
		$message .= "<p>E mail : " . $_POST['email'] . "</p>";
		$message .= "<p>Mobile : " . $_POST['mobileno'] . "</p>";
		$message .= "<p>Comment : " . $_POST['comment'] . "</p>";
		$headers = "From: OMSINFOTECH\r\n" ;
		$headers .= 'MIME-Version: 1.0' . "\r\n";
		$headers .= 'Content-type: text/html;' . "\r\n";
		if(mail($mail_to,$subject,$message,$headers)) {
			echo "<script>
			 alert('You Have Submitted Successfully We Will Contact Soon !');
			
			window.location = '../contact.html'</script>";
			
		} else {
			echo "<script>
				 alert('Went Wrong We Will Contact Soon !');
				window.location = '../contact.html'</script>";
		}
	}
?>