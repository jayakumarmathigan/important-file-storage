<?php
$array1= array();
function fetch_news(){
	$data = file_get_contents('http://rss.dinamalar.com/?cat=ara1');
	$data = simplexml_load_string($data);
    $articles = array();
	foreach ($data->channel->item as $item){
		$articles[]=array(
			'title'       =>(string)$item->title,
			'description'  =>(string)$item->description,
			'link'          =>(string)$item->link,
			'date'          =>(string)$item->pubDate,
		
		);
		
	}
		return $articles;
	//print_r(array_reverse($articles));
	?>

<!--    <table>
    <tr>
    <td></td>
    <td></td>
    <td></td>
    <td></td></tr>
-->   
    <?php
    /*foreach (array_reverse($articles) as $key => $value){
	echo '<tr><td>';
	echo '<tr class="thap"><td>'.$value['title'].'</td></tr>';
	echo '<tr class="hap"><td>'.$value['description'].'</td></tr>';
	echo '<tr class="ap" ><td>'.$value['date'].'</td></tr>';
	echo '<tr class="happ"><td>'.$value['link'].'</td></tr>';
	}*/
}
?>
 
 
 <?php
$array2= array();
function etch_news($arr){
	$data = file_get_contents('http://www.dinakaran.com/rss_news.asp?id=9');
	$data = simplexml_load_string($data);
    $articles1 = array();
	foreach ($data->channel->item as $item){
		$articles1[]=array(
			'title'       =>(string)$item->title,
			'description'  =>(string)$item->description,
			'link'          =>(string)$item->link,
			'date'          =>(string)$item->pubDate,
			
		);
		
		}
		
	//print_r(array_reverse($articles));
	$arr1 = array_merge(array_reverse($arr),($articles1));
	//array_multisort($arr1);
?>
  
  <div class="col-md-8 col-lg-8 col-sm-12 col-xs-12">
  <div class="oa">
    <table>
    <tr>
    <td></td>
    <td></td>
    <td></td>
    <td></td></tr>
   
    <?php
    foreach ($arr1 as $key => $value){
	echo '<tr><td>';
	echo '<tr class="thap"><td>'.$value['title'].'</td></tr>';
	echo '<tr class="hap"><td>'.$value['description'].'</td></tr>';
	echo '<tr class="happ"><td>'.$value['link'].'</td></tr>';
	echo '<tr class="ap" ><td>'.$value['date'].'</td></tr>';
	
	}
	
}

?>
</table>
</div>
 </div>
 
<!DOCTYPE html>
<html lang="en">
<head>	
		<title>Todays News</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		
		<link rel="stylesheet" href="core/inc/css/style.css">
        <link rel="stylesheet" href="core/inc/css/bootstrap.css">
		<link rel="stylesheet" href="core/inc/font-awesome/css/font-awesome.css">
	    <link rel="stylesheet" href="core/inc/font-awesome/css/font-awesome.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
		
		
  
  

<style>
 
  .affix {
      top: 30px;
  }
  </style>        
</head>
<body>
<div class="bg">
<div class="container">

<div class="wht">
<div class="col-md-8 col-sm-4 col-xs-6">
<div class="logo">
<img src="images/news.png" class="img-responsive" style="width:30%">
</div>
</div>
<div class="col-md-4 col-sm-4 xs-hidden">
<div class="nl">
NewsLetter SignUp
</div>
</div>

<div class="clearfix"> </div>

	<div class="banner">
	
		<img src="core/inc/sdf.jpg" class="img-responsive" style="width:100%">
		<!--<iframe width="1350" height="600" src="https://www.youtube.com/embed/5zM__HskYoo?autoplay=1" style="position: relative; opacity: 0.5;"></iframe>-->
	</div>
<div class="bn">

<div class="col-md-3 col-sm-3 col-xs-3">
<img src="images/ne.jpg" class="img-responsive" style="width:100%">
</div>
<div class="col-md-3 col-sm-3 col-xs-3">
<img src="images/ui.jpg" class="img-responsive" style="width:100%">
</div>
<div class="col-md-3 col-sm-3 col-xs-3">
<img src="images/nbhj.jpg" class="img-responsive" style="width:100%">
</div>
<div class="col-md-3 col-sm-3 col-xs-3">
<img src="images/df.jpg" class="img-responsive" style="width:100%">
</div>
</div>



<div class="mnb" data-spy="affix" data-offset-top="205">
<div class="col-md-8 col-sm-8 xs-hidden">
<div class="rmpa">
 <img src="images/nf.jpg">
</div>
</div>


<div class="col-md-4 col-sm-4  xs-hidden">
<div class="adv">
<img src="images/newzz.jpg">
</div>
<div class="adva">
<!--<a href="https://www.facebook.com/search/top/?q=gtr" target="_new">--><img src="images/fbb.jpg">
</div>
</div>
</div>

</body>
</html>
