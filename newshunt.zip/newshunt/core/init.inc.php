<?php
//$path = dirname(_FILE_);
include($rpath.'inc/bbc.php');

?>








